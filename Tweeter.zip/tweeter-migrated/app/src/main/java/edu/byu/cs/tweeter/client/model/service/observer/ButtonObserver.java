package edu.byu.cs.tweeter.client.model.service.observer;

public interface ButtonObserver extends ServiceObserver{
    void setFollowingButton();
    void setFollowButton();
}
